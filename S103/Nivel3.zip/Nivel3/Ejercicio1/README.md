# Ejercicio 1 - Nivel 3

## Enunciado

Dado un array de enteros, crea un programa que:

- Devuelva cada valor del array elevado al cubo.
- Utiliza la función `array_map`.

## Objetivo

Practicar el uso de `array_map` y funciones anónimas.

## Código de ejemplo

<?php
$numeros = [1, 2, 3, 4, 5];

$cubos = array_map(function($n) {
    return $n ** 3;
}, $numeros);

print_r($cubos);
