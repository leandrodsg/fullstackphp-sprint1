# Ejercicio 3 - Nivel 3

## Enunciado

Dado un array de enteros, crea un programa que:

- Devuelva la suma de todos los números del array que sean primos.
- Utiliza la función `array_reduce`.

## Objetivo

Practicar `array_reduce`, funciones personalizadas y lógica de números primos.

## Código de ejemplo

<?php
function esPrimo($num) {
    if ($num <= 1) return false;
    for ($i = 2; $i <= sqrt($num); $i++) {
        if ($num % $i === 0) return false;
    }
    return true;
}

$numeros = [2, 3, 4, 5, 6, 7, 8, 9];

$primos = array_filter($numeros, 'esPrimo');

$suma = array_reduce($primos, fn($carry, $n) => $carry + $n, 0);

echo "Suma de primos: $suma";
