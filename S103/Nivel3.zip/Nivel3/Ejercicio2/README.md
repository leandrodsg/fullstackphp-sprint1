# Ejercicio 2 - Nivel 3

## Enunciado

Dado un array de strings, crea un programa que:

- Devuelva un array con los nombres que contengan una vocal determinada.
- Utiliza la función `array_filter`.

## Objetivo

Practicar `array_filter` y manejo de strings.

## Código de ejemplo

<?php
$nombres = ["Ana", "Luis", "Carlos", "Edu", "Sofia"];
$vocal = 'a';

$filtrados = array_filter($nombres, function($nombre) use ($vocal) {
    return stripos($nombre, $vocal) !== false;
});

print_r($filtrados);
